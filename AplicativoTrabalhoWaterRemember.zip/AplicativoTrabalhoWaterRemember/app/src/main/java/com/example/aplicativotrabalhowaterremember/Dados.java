package com.example.aplicativotrabalhowaterremember;


import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Dados {
    private  String data;
    private int qntcopos;
    private Double peso;
    private BancoDados bd;

    public Date dataHoraAtual = new Date();
    public Dados( int qntcopos, Double peso) {

        this.data = new SimpleDateFormat("yyyy/MM/dd").format(dataHoraAtual);
        this.qntcopos = qntcopos;
        this.peso = peso;
        this.salvar();

    }

    public Dados(){
        this.data = new SimpleDateFormat("yyyy/MM/dd").format(dataHoraAtual);
    }

    public String getData() {
        Dados dado = bd.PegaInfo(this.data);
        return dado.data;
    }

    public void setData(String data) {

        this.data = data;
        this.salvar();
    }

    public int getQntcopos() {
        Dados dado = bd.PegaInfo(this.data);
        return dado.qntcopos;
    }

    public void setQntcopos(int qntcopos) {

        this.qntcopos= qntcopos;
        this.salvar();
    }

    public Double getPeso() {
        Dados dado = bd.PegaInfo(this.data);
        return dado.peso;

    }

    public void setPeso(Double peso) {
        this.peso = peso;
        this.salvar();
    }

    public void salvar(){
        Log.d("salvar.bd",bd.SalvaInfo(this));
    }
}

package com.example.aplicativotrabalhowaterremember;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.health.ProcessHealthStats;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;


import com.example.aplicativotrabalhowaterremember.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private Button btnMais;
    private int progress = 0;
    ProgressBar progressBar;
    int qntUmCopo;
    TextView textView;
    ImageView img;

  /* public Date dataHoraAtual = new Date();
   public String hoje  =  new SimpleDateFormat("yyyy/MM/dd").format(dataHoraAtual);
    public Dados dado = new Dados();*/

    public  float valorTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //atualizando as informaçoes da tela com base no banco
      /*  if(dado.getPeso()==null){
            Toast.makeText(MainActivity.this, "Calcule sua quantidade diária de água no botão da direita!", Toast.LENGTH_SHORT).show();
        }*/


        /* pacote que vem da activity Settings*/
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("key");
            valorTotal=Float.parseFloat(value);
            Toast.makeText(MainActivity.this, "Valor: "+valorTotal, Toast.LENGTH_SHORT).show();
            qntUmCopo = (int) (20000/valorTotal);
        }
        else {
            Toast.makeText(MainActivity.this, "Calcule sua quantidade diária de água no botão da direita!", Toast.LENGTH_SHORT).show();
        }

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);

        btnMais = findViewById(R.id.btnMais);
        btnMais.setOnClickListener(new View.OnClickListener()
        {
            public void onClick (View v) {
                Intent conf_main = new Intent(MainActivity.this, Settings.class);
                startActivity(conf_main);
            }
        });

        progressBar = (ProgressBar) findViewById(R.id.progress_bar);
        textView = (TextView) findViewById(R.id.text_view_progress);
        img = findViewById(R.id.imageView);

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(valorTotal==0){
                    Toast.makeText(MainActivity.this, "Configure sua meta diária!", Toast.LENGTH_SHORT).show();
                }
                else{
                if (progress <= 99) {
                    progress += qntUmCopo;
                    updateProgressBar();
                    if (progressBar.getProgress() >= 100){
                        textView.setText("100");
                        Toast.makeText(MainActivity.this, "Você concluiu sua meta \uD83D\uDC4F", Toast.LENGTH_SHORT).show();
                    }
                }
                }


            }
        });
    }
    private void updateProgressBar() {
        progressBar.setProgress(progress);
        textView.setText(String.valueOf(progress));
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://pt.m.wikipedia.org/wiki/%C3%81gua_pot%C3%A1vel#:~:text=A%20%C3%A1gua%20%C3%A9%20essencial%20para,menos%20de%203%20litros%20di%C3%A1rios")));
        }

        return super.onOptionsItemSelected(item);
    }


}